# Guia Teórico de CSS

## 📚 Sobre o Projeto

Este projeto é um site estático que apresenta um guia teórico completo sobre CSS (Cascading Style Sheets). O objetivo é fornecer um recurso educacional abrangente para desenvolvedores web, especialmente estudantes de desenvolvimento full stack, que desejam compreender os fundamentos e conceitos avançados do CSS.

O site foi desenvolvido com foco em design responsivo, experiência do usuário e acessibilidade, aplicando os próprios conceitos de CSS que são explicados no conteúdo.

## 🌟 Características

- **Design Responsivo**: Adaptação perfeita para dispositivos móveis, tablets e desktops
- **Tema Claro/Escuro**: Alternância entre modos de visualização para melhor conforto visual
- **Navegação Intuitiva**: Menu de navegação fixo no topo para fácil acesso às seções
- **Animações Suaves**: Transições e efeitos para melhorar a experiência do usuário
- **Código Semântico**: HTML estruturado seguindo as melhores práticas de acessibilidade
- **Conteúdo Detalhado**: Explicações completas sobre os principais conceitos de CSS

## 📋 Conteúdo

O guia aborda os seguintes tópicos:

1. **Introdução ao CSS**: Conceitos básicos e importância da separação entre estrutura e apresentação
2. **Cascata e Especificidade**: Como o CSS resolve conflitos entre regras de estilo
3. **Sintaxe Básica**: Estrutura das regras CSS e como aplicá-las
4. **Seletores**: Diferentes tipos de seletores e como usá-los com precisão
5. **Modelo de Caixa (Box Model)**: Compreensão do espaço dos elementos na página
6. **Posicionamento**: Controle da localização dos elementos com a propriedade position
7. **Layout**: Técnicas modernas como Flexbox e Grid para organização do conteúdo
8. **Boas Práticas**: Design responsivo, unidades relativas, variáveis CSS e organização do código

## 🛠️ Tecnologias Utilizadas

- **HTML5**: Estrutura semântica do conteúdo
- **CSS3**: Estilização e layout responsivo
- **JavaScript**: Interatividade, navegação suave e alternância de tema
- **Font Awesome**: Ícones utilizados na interface
- **Google Fonts**: Tipografia aprimorada

## 🚀 Demonstração

O site está disponível em: [https://anijytxu.manus.space](https://anijytxu.manus.space)

## 📥 Como Usar

1. Clone este repositório:
   ```bash
   git clone https://github.com/guilherme356/guia-teorico-css.git
   ```

2. Abra o arquivo `index.html` em seu navegador para visualizar o site localmente.

3. Para modificar o conteúdo:
   - Edite o arquivo `index.html` para alterar a estrutura e o texto
   - Modifique `css/styles.css` para ajustar o design
   - Atualize `js/script.js` para alterar o comportamento interativo

## 📱 Responsividade

O site foi projetado para funcionar em diversos tamanhos de tela:
- **Desktop**: Layout completo com todas as funcionalidades
- **Tablet**: Adaptação do menu e redimensionamento dos elementos
- **Mobile**: Reorganização do conteúdo para melhor visualização em telas pequenas

## 🌐 Publicação com GitHub Pages

Este projeto pode ser facilmente publicado usando o GitHub Pages:

1. Vá para a aba "Settings" do seu repositório
2. Navegue até a seção "Pages"
3. Selecione a branch principal (geralmente "main") como fonte
4. Clique em "Save" e aguarde alguns minutos para que o site seja publicado
5. O URL do seu site será exibido na seção GitHub Pages

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 👤 Autor

**Guilherme**
- GitHub: [@guilherme356](https://github.com/guilherme356)

## 🙏 Agradecimentos

- MDN Web Docs pela documentação de referência sobre CSS
- Eliseo Vega pelo guia de CSS utilizado como referência
- Universidad de los Andes pelo manual básico de programação HTML e CSS

---

⭐️ Se este projeto foi útil para você, considere dar uma estrela no GitHub!
