# Instruções para Publicação no GitHub

Este documento contém instruções passo a passo para publicar o Guia Teórico de CSS no seu GitHub e ativar o GitHub Pages.

## 1. Baixar os Arquivos do Projeto

Primeiro, você precisa baixar todos os arquivos do projeto para o seu computador:

1. Clique no botão abaixo para baixar o projeto completo como um arquivo ZIP:
   [Baixar Projeto (ZIP)](https://anijytxu.manus.space/download/css-guide-github.zip)

2. Extraia o arquivo ZIP em uma pasta no seu computador.

## 2. Criar um Novo Repositório no GitHub

1. Acesse [GitHub.com](https://github.com) e faça login na sua conta.
2. Clique no botão "+" no canto superior direito e selecione "New repository".
3. Preencha as informações do repositório:
   - Nome do repositório: `guia-teorico-css` (ou outro nome de sua preferência)
   - Descrição: "Guia teórico completo sobre CSS para desenvolvedores web"
   - Visibilidade: Pública (recomendado para GitHub Pages)
   - Não inicialize o repositório com README, .gitignore ou licença (já temos esses arquivos)
4. Clique em "Create repository".

## 3. Enviar os Arquivos para o GitHub

Abra o terminal (ou Git Bash no Windows) e navegue até a pasta onde você extraiu os arquivos:

```bash
# Navegue até a pasta do projeto
cd caminho/para/pasta/extraida

# Inicialize o repositório Git (se ainda não estiver inicializado)
git init

# Configure seu usuário e email (se ainda não configurado)
git config user.name "Seu Nome"
git config user.email "seu-email@exemplo.com"

# Adicione todos os arquivos ao repositório
git add .

# Faça o commit inicial
git commit -m "Projeto inicial: Guia Teórico de CSS"

# Adicione o repositório remoto (substitua 'guilherme356' pelo seu nome de usuário)
git remote add origin https://github.com/guilherme356/guia-teorico-css.git

# Envie os arquivos para o GitHub
git push -u origin master
```

Nota: Se o seu branch padrão for 'main' em vez de 'master', use:
```bash
git branch -M main
git push -u origin main
```

## 4. Ativar o GitHub Pages

1. Acesse seu repositório no GitHub.
2. Clique na aba "Settings" (Configurações).
3. No menu lateral esquerdo, clique em "Pages" (pode estar dentro de "Code and automation").
4. Na seção "Source", selecione a branch principal (master ou main).
5. Clique em "Save".
6. Aguarde alguns minutos para que o GitHub Pages seja ativado.
7. Após a ativação, você verá uma mensagem com o URL do seu site (geralmente https://[seu-usuario].github.io/guia-teorico-css/).

## 5. Verificar a Publicação

1. Acesse o URL fornecido pelo GitHub Pages para verificar se o site está funcionando corretamente.
2. Teste a navegação, o tema claro/escuro e a responsividade.

## 6. Personalizar o Projeto (Opcional)

Você pode personalizar o projeto conforme desejar:
- Edite o arquivo `index.html` para modificar o conteúdo.
- Altere o arquivo `css/styles.css` para ajustar o design.
- Modifique o arquivo `js/script.js` para alterar o comportamento interativo.
- Atualize o README.md com informações adicionais sobre o projeto.

## 7. Adicionar ao seu Portfólio

Após a publicação, você pode adicionar este projeto ao seu portfólio:
1. Inclua o link do repositório e do site publicado no seu currículo.
2. Destaque as tecnologias utilizadas (HTML, CSS, JavaScript).
3. Mencione os conceitos aplicados (design responsivo, temas, acessibilidade).

## Suporte

Se tiver dúvidas ou precisar de ajuda, você pode:
- Consultar a [documentação do GitHub Pages](https://docs.github.com/pt/pages)
- Verificar o [guia de Git](https://git-scm.com/book/pt-br/v2)
